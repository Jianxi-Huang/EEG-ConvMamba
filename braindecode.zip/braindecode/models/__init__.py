"""
Some predefined network architectures for EEG decoding.
"""
