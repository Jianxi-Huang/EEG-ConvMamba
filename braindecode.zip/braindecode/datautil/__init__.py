"""
Utilities for data manipulation.
"""
