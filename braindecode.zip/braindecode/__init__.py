from braindecode.version import __version__
